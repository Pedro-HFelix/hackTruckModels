//
//  projeFinalEntidadesRotasApp.swift
//  projeFinalEntidadesRotas
//
//  Created by Turma01-22 on 04/04/25.
//

import SwiftUI

@main
struct projeFinalEntidadesRotasApp: App {
    var body: some Scene {
        WindowGroup {
            Home()
        }
    }
}
