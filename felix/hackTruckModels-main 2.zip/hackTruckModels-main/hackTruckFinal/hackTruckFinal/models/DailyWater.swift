//
//  DailyWater.swift
//  hackTruckFinal
//
//  Created by Turma01-22 on 09/04/25.
//

import Foundation

struct DailyWater: Identifiable, Decodable, Encodable{
    var id: Int?
    var quantity: Int?
    var date: Date?
}
