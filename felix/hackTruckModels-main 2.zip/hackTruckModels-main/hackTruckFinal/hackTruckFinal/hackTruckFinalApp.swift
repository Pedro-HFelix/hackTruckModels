//
//  hackTruckFinalApp.swift
//  hackTruckFinal
//
//  Created by Turma01-22 on 07/04/25.
//

import SwiftUI

@main
struct hackTruckFinalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
